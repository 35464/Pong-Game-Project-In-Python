from turtle import Turtle, Screen
from paddle import Paddle
from ball import Ball
from score_board import ScoreBoard
import time

screen = Screen()
screen.setup(width=800, height=600)
screen.bgcolor('black')
screen.title('Pong_Game')
turtle = Turtle()

screen.tracer(0)

# divide the screen
turtle.hideturtle()
turtle.penup()
turtle.goto(0, -300)
turtle.setheading(90)
turtle.speed("fastest")

for _ in range(15):
    turtle.pencolor('white')
    turtle.pendown()
    turtle.forward(20)
    turtle.penup()
    turtle.forward(20)


r_paddle = Paddle((350, 0))
l_paddle = Paddle((-350, 0))


screen.listen()
screen.onkey(key='Up', fun=r_paddle.move_up)
screen.onkey(key='Down', fun=r_paddle.move_down)

screen.onkey(key='w', fun=l_paddle.move_up)
screen.onkey(key='s', fun=l_paddle.move_down)

ball = Ball()
scoreboard = ScoreBoard()
game_is_on = True

while game_is_on:
    time.sleep(ball.move_speed)
    screen.update()
    ball.move()

    if ball.ycor() > 280 or ball.ycor() < -280:
        ball.bounce_y()

    if ball.distance(r_paddle) < 50 and ball.xcor() > 320:
        ball.bounce_x()

    if ball.distance(l_paddle) < 50 and ball.xcor() < -320:
        ball.bounce_x()


# Detect when Right side paddle miss the Ball

    if ball.xcor() > 380:
        ball.reset_position()

        scoreboard.increaselscore()

# detect when left side paddle miss the Ball

    if ball.xcor() < -380:
        ball.reset_position()
        scoreboard.increase_rscore()

screen.exitonclick()
